
public class Driver {

	public static void main(String[] args) {
		Photo P = new Photo(11,23,"Sony");
		P.ToString();
		
		House H = new House(10, 22, "Kgn", "Utech",P);
		H.ToString();
		
		
	}
}
